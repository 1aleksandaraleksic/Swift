//
//  Helper.swift
//  audiEventi
//
//  Created by aleksandar.aleksic on 1.7.21..
//

import Foundation
import UIKit

extension UIViewController{
    
    func prepareNavigationBar(){
        navigationItem.leftBarButtonItem = UIBarButtonItem(title: "...", style: .done, target: self, action: #selector(showBurgerVC))
        navigationItem.leftBarButtonItem?.image = UIImage(named: "menu")
        
        let imageView = UIImageView(frame: CGRect(x: 0, y: 0, width: 20, height: 20))
        imageView.contentMode = .scaleAspectFit
        imageView.image = UIImage(named: "audi_logo")
        navigationItem.titleView = imageView
    }
    
    func presentDetail(_ vc: UIViewController) {
        let transition = CATransition()
        transition.duration = 0.5
        view.window?.layer.add(transition, forKey: kCATransition)
        vc.modalPresentationStyle = .overCurrentContext
        present(vc, animated: false, completion: nil)
    }
    
    @objc func showBurgerVC(){
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(identifier: "BurgerVC")
        presentDetail(vc)
    }
    
    func activateGestureDissmisForBurgerVC(){
        let tap = UITapGestureRecognizer(target: self, action: #selector(BurgerVC.tappedOnScreen(_:)))
        view.addGestureRecognizer(tap)
    }
    
    @objc func tappedOnScreen(_ sender: UIGestureRecognizer) {
        let tapped = sender.location(in: view)
        let screenWidth = UIScreen.main.bounds.width
        if  tapped.x > screenWidth - 80 && tapped.y > 0 {
            let transition = CATransition()
            transition.duration = 0.5
            view.window?.layer.add(transition, forKey: kCATransition)
            dismiss(animated: false, completion: nil)
        }
    }
    
    @objc func showAlertForCoupon() {
        let alert = UIAlertController(title: "KUPON", message: "Unesi kupon broj: ", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .cancel))
        alert.addTextField { (textField) in
            textField.placeholder = "AUDI2345678"
        }
        self.present(alert, animated: true)
    }
}


class PrepareElementForBurgerVC{
    
    @objc func namedActionToShow(name: String, viewController: UIViewController) -> (){
//
        switch name {
        case "menu_home":
            
            break
        case "menu_calendar":
            break
        case "menu_coupon_eventi":
//            return viewController.showAlertForCoupon("Unesite KUPON")
            break
        case "menu_info":
            break
        default:
            return
        }
        
    }

}
